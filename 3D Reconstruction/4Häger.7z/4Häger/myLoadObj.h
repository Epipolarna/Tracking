// Player.h, Container for player related actions and information

#include "Model.h"
	
void myLoadObj(char* filename, Model* model);
